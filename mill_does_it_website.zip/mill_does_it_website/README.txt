MILL DOES IT — WEBSITE FILES

Included:
- index.html: Complete responsive one-page website. HTML, CSS, and a tiny year script are all included in one file.

HOW TO PREVIEW ON YOUR IPAD
1. Download and unzip this folder.
2. Open index.html in a browser or an HTML preview app. If iPadOS won't preview the file directly, use the GitHub Pages publishing steps below.

HOW TO PUBLISH FREE WITH GITHUB PAGES
1. Create/sign into a GitHub account at https://github.com/
2. Create a NEW PUBLIC repository named: mill-does-it
3. Upload index.html to the repository's main/root folder.
4. Open the repository's Settings, then Pages.
5. Under the build/deployment source, choose Deploy from a branch.
6. Choose the main branch and /(root), then Save.
7. Wait for the published link to appear on the Pages screen. It will usually look like https://YOUR-USERNAME.github.io/mill-does-it/
GitHub's interface may change; follow its current Pages instructions if labels differ.

IMPORTANT BEFORE GOING LIVE
- Confirm with your uncle that the business name, phone number, Philadelphia service area, and listed services are correct.
- Replace any wording he wants changed.
- This site uses a tap-to-call button and a tap-to-text button. It does NOT have a backend form that stores submissions.
- Do not add an address, business hours, insurance/licensing claims, testimonials, prices, or service guarantees unless your uncle confirms them.
- A free GitHub Pages address does not include website-builder branding. A custom .com domain usually costs extra.
